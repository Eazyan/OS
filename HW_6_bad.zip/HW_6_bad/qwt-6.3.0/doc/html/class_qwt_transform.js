var class_qwt_transform =
[
    [ "QwtTransform", "class_qwt_transform.html#aa1fa1ab21d0fc01e06d3a6e462008d0b", null ],
    [ "~QwtTransform", "class_qwt_transform.html#aa2653db3104e672464dc569592fc14ab", null ],
    [ "bounded", "class_qwt_transform.html#aef97acf17f900905f2a93cec7f61e643", null ],
    [ "copy", "class_qwt_transform.html#a040a268141771b4e1b4723dcf343d077", null ],
    [ "invTransform", "class_qwt_transform.html#a5cfb0a329b8418028baf6974b188d76b", null ],
    [ "transform", "class_qwt_transform.html#a1093b5856cbc6cf812460535442fb130", null ]
];