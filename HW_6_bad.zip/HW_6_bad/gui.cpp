#include <QApplication>
#include <QWidget>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QUrl>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QJsonDocument>
#include <QJsonObject>
#include <qwt.cpp>
#include <qwt.h>

class TemperatureApp : public QWidget
{
    Q_OBJECT

public:
    explicit TemperatureApp(QWidget *parent = nullptr)
        : QWidget(parent), networkManager(new QNetworkAccessManager(this))
    {
        setWindowTitle("Temperature App");

        QVBoxLayout *layout = new QVBoxLayout(this);

        label = new QLabel("Current Temperature: ", this);
        layout->addWidget(label);

        QPushButton *button = new QPushButton("Fetch Temperature", this);
        layout->addWidget(button);

        connect(button, &QPushButton::clicked, this, &TemperatureApp::fetchTemperature);

        setLayout(layout);
    }

private slots:
    void fetchTemperature()
    {
        QUrl url("https://api.openweathermap.org/data/2.5/weather?q=Dublin&appid=YOUR_API_KEY");
        QNetworkRequest request(url);
        QNetworkReply *reply = networkManager->get(request);
        connect(reply, &QNetworkReply::finished, this, &TemperatureApp::handleResponse);
    }

    void handleResponse()
    {
        QNetworkReply *reply = qobject_cast<QNetworkReply *>(sender());
        if (reply && reply->error() == QNetworkReply::NoError) {
            QByteArray response = reply->readAll();
            QJsonDocument jsonDoc = QJsonDocument::fromJson(response);
            QJsonObject jsonObj = jsonDoc.object();
            double tempKelvin = jsonObj["main"].toObject()["temp"].toDouble();
            double tempCelsius = tempKelvin - 273.15; // Convert from Kelvin to Celsius

            label->setText("Current Temperature: " + QString::number(tempCelsius) + "°C");
        } else {
            label->setText("Error fetching temperature.");
        }
        reply->deleteLater();
    }

private:
    QNetworkAccessManager *networkManager;
    QLabel *label;
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    TemperatureApp window;
    window.show();

    return app.exec();
}

#include "gui.moc"
