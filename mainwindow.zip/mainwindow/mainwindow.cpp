#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <Qwt_Plot.h>
#include <Qwt_Plot_Curve.h>
#include <QPen>
#include <QVector>
#include <QPointF>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Создаем объект QwtPlot и передаем в него контейнер, добавленный через Qt Designer
    plot = new QwtPlot(ui->plotContainer); // plotContainer - это имя виджета в Qt Designer

    // Устанавливаем размеры и позицию для QwtPlot внутри контейнера
    plot->setGeometry(10, 10, 780, 580);

    // Создаем кривую для графика
    curve = new QwtPlotCurve();
    curve->setTitle("Синусоида");
    curve->setPen(QPen(Qt::blue)); // Устанавливаем синий цвет для линии

    // Массив точек для кривой синусоиды
    QVector<QPointF> points;
    for (double i = 0; i < 100; ++i) {
        points.append(QPointF(i, sin(i * M_PI / 50.0)));
    }

    // Создаем QwtPointSeriesData для кривой
    QwtPointSeriesData *data = new QwtPointSeriesData(points);

    // Устанавливаем данные для кривой
    curve->setData(data);

    // Добавляем кривую на график
    curve->attach(plot);

    // Настройка осей графика
    plot->setAxisScale(QwtPlot::xBottom, 0, 100);  // Ось X
    plot->setAxisScale(QwtPlot::yLeft, -1, 1);     // Ось Y
    plot->replot();  // Перерисовываем график
}

MainWindow::~MainWindow()
{
    delete ui;
}
