#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <Qwt_Plot.h>  // Добавляем библиотеку для графика
#include <Qwt_Plot_Curve.h>  // Для рисования кривых на графике

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QWidget
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QwtPlot *plot;  // Указатель на QwtPlot для отображения графика
    QwtPlotCurve *curve;  // Для рисования кривой на графике
};
#endif // MAINWINDOW_H
