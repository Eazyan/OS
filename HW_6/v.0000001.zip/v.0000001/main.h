#ifndef MAIN_H
#define MAIN_H

#include <QWidget>
#include <QVector>
#include <QwtPlot>
#include <QwtPlotCurve>
#include <QwtPlotRenderer>
#include <QTimer>
#include <QRandomGenerator>
#include <QTime>

class TemperatureMonitor : public QWidget
{
    Q_OBJECT
public:
    explicit TemperatureMonitor(QWidget *parent = nullptr);
    ~TemperatureMonitor();

private slots:
    void updateTemperature();  // Добавляем слот для обновления температуры

private:
    QTimer *timer;  // Таймер для обновления данных
};


#endif // MAIN_H
