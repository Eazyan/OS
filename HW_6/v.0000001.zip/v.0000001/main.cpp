#include <QApplication>
#include <QWidget>
#include <QVBoxLayout>
#include <Qwt_Plot.h>
#include <Qwt_Plot_Curve.h>
#include <Qwt_Series_Data.h>
#include <QPointF>
#include <vector>
#include <iostream>
#include <QTimer>

// main.cpp или TemperatureMonitor.cpp

#include "TemperatureMonitor.h"
#include "ui_main.h"  // Включаем сгенерированный файл интерфейса

TemperatureMonitor::TemperatureMonitor(QWidget *parent)
    : QWidget(parent), ui(new Ui::Main) {  // Используем Ui::Main
    ui->setupUi(this);  // Настроить интерфейс
}

TemperatureMonitor::~TemperatureMonitor() {
    delete ui;  // Очистка после завершения
}


// Деструктор
TemperatureMonitor::~TemperatureMonitor() {
    // Очистка ресурсов, если нужно
}

// Реализация updateTemperature() (например, для обновления температуры)
void TemperatureMonitor::updateTemperature() {
    // Пример обновления температуры (или обработки)
    std::cout << "Обновление температуры!" << std::endl;
}


class PointSeriesData : public QwtSeriesData<QPointF> {
public:
    PointSeriesData(const std::vector<QPointF>& points) : points_(points) {}

    // Реализация метода size
    size_t size() const override {
        return points_.size();
    }

    // Реализация метода sample
    QPointF sample(size_t i) const override {
        return points_.at(i);
    }

private:
    std::vector<QPointF> points_;
};

class TemperaturePlot : public QWidget {
public:
    TemperaturePlot(QWidget *parent = nullptr) : QWidget(parent) {
        QVBoxLayout *layout = new QVBoxLayout(this);

        // Создаем график
        plot = new QwtPlot(this);
        plot->setTitle("График температуры");
        plot->setCanvasBackground(Qt::white);

        // Добавляем график в layout
        layout->addWidget(plot);

        // Создаем кривую для графика
        curve = new QwtPlotCurve();
        curve->setTitle("Температура");
        curve->setPen(Qt::blue, 2);

        // Пример данных для графика (температура по времени)
        xData = {1.0, 2.0, 3.0, 4.0, 5.0};  // Время (например, минуты)
        yData = {10.0, 15.0, 20.0, 25.0, 30.0};  // Температура (°C)

        // Преобразуем данные в массив объектов QPointF
        std::vector<QPointF> points;
        for (size_t i = 0; i < xData.size(); ++i) {
            points.push_back(QPointF(xData[i], yData[i]));
        }

        // Создаем PointSeriesData и передаем его в setData
        PointSeriesData* seriesData = new PointSeriesData(points);
        curve->setData(seriesData);

        // Добавляем кривую на график
        curve->attach(plot);

        // Устанавливаем оси графика
        plot->setAxisTitle(QwtPlot::xBottom, "Время (мин.)");
        plot->setAxisTitle(QwtPlot::yLeft, "Температура (°C)");

        // Настроим таймер для обновления данных (каждую секунду)
        QTimer *timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &TemperaturePlot::updatePlot);
        timer->start(1000);  // 1 секунда
    }

private slots:
    void updatePlot() {
        // Для демонстрации будем добавлять новые данные к графику
        // В реальной программе здесь нужно будет получить актуальные данные

        // Пример добавления нового значения
        static double time = 6.0;
        static double temp = 35.0;

        // Добавляем новые данные
        xData.push_back(time);
        yData.push_back(temp);

        // Обновляем график с новыми данными
        std::vector<QPointF> points;
        for (size_t i = 0; i < xData.size(); ++i) {
            points.push_back(QPointF(xData[i], yData[i]));
        }

        // Создаем новый PointSeriesData и обновляем данные графика
        PointSeriesData* seriesData = new PointSeriesData(points);
        curve->setData(seriesData);

        // Увеличиваем время и температуру для следующего обновления
        time += 1.0;
        temp += 1.0;

        plot->replot();  // Перерисовываем график
    }

private:
    QwtPlot *plot;
    QwtPlotCurve *curve;
    std::vector<double> xData;  // Массив времени
    std::vector<double> yData;  // Массив температур
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    TemperaturePlot window;
    window.resize(800, 600);
    window.show();

    return app.exec();
}
