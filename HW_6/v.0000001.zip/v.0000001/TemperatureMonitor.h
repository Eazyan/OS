#ifndef TEMPERATUREMONITOR_H
#define TEMPERATUREMONITOR_H

#include <QWidget>

namespace Ui {
class Main;  // Прокси-класс для Main.ui
}

class TemperatureMonitor : public QWidget
{
    Q_OBJECT

public:
    explicit TemperatureMonitor(QWidget *parent = nullptr);
    ~TemperatureMonitor();

private:
    Ui::Main *ui;  // Указываем, что ui будет экземпляром класса Ui::Main
};

#endif // TEMPERATUREMONITOR_H
